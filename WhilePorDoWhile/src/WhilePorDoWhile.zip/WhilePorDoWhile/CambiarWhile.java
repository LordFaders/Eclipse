package WhilePorDoWhile;

public class CambiarWhile {

	  public static void main(String[] args) {
		/*int i = 0;
		while (i < 50) {
			i += 1;
			System.out.printf("Iteración %d\n", i);
		}*/
		  int i = 0;
		  do {
		  System.out.printf("Iteración %d\n", i++);
		  }while (i < 50);
		  
	}

}
